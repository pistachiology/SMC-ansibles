#!/bin/bash
java -cp "../../sepia.jar:../../pptks.jar" -Djavax.net.ssl.trustStore=peer03KeyStore.jks  MainCmd -p 0 -c config.peer03.properties