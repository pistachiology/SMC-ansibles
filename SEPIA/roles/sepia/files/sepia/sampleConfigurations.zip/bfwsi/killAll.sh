#!/bin/bash
killall -u $(whoami) java 
