#!/bin/bash
java -server -cp "../../sepia.jar:../../benchmark.jar" -Djavax.net.ssl.trustStore=privacypeer04KeyStore.jks  MainCmd -p 1 -c config.privacypeer04.properties