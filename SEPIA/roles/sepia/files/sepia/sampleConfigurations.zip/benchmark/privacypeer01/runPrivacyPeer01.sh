#!/bin/bash
java -server -cp "../../sepia.jar:../../benchmark.jar" -Djavax.net.ssl.trustStore=privacypeer01KeyStore.jks  MainCmd -p 1 -c config.privacypeer01.properties