#!/bin/bash
java -cp "../../sepia.jar:../../statistics.jar" -Djavax.net.ssl.trustStore=privacypeer02KeyStore.jks  MainCmd  -p 1 -c config.privacypeer02.properties