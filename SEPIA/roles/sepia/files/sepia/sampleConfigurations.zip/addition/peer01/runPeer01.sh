#!/bin/bash
java -cp "../../sepia.jar:../../statistics.jar" -Djavax.net.ssl.trustStore=peer01KeyStore.jks  MainCmd -p 0 -c config.peer01.properties
