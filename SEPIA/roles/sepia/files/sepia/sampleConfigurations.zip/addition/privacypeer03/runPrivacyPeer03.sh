#!/bin/bash
java -cp "../../sepia.jar:../../statistics.jar" -Djavax.net.ssl.trustStore=privacypeer03KeyStore.jks  MainCmd -p 1 -c config.privacypeer03.properties