#!/bin/sh
java -jar MakeConfig.jar g
